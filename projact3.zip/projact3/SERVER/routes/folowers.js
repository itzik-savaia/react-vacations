var express = require('express');
var router = express.Router();
var vacationAPI = require('./conroller&&API/folowers');



// /* PUT Single-vacation-Api. */
// router.put('/put/:id', vacationAPI.putSingle);

// /* DELETE Single-vacation-Api. */
// router.delete('/delete/:id', vacationAPI.deleteSingle);