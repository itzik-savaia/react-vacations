module.exports = {
    'secret': 'grokonez-super-secret-key',
    ROLEs: ['USER', 'ADMIN', 'PM']
};